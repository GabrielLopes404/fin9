import { db } from "./db";
import { permissions, rolePermissions } from "@shared/schema";
import { eq, and } from "drizzle-orm";
import { clearPermissionCache } from "./rbac";

/**
 * Migration script to add new export permissions and CRUD permissions
 * for customers and invoices. Can be run safely multiple times (idempotent).
 */
export async function migratePermissions() {
  console.log('Starting permission migration...');
  
  try {
    // Define all new permissions to be added
    const newPermissions = [
      // Export permissions
      { name: 'export_transactions', resource: 'transactions', action: 'export', description: 'Export transactions to CSV/Excel' },
      { name: 'export_customers', resource: 'customers', action: 'export', description: 'Export customers to CSV/Excel' },
      { name: 'export_invoices', resource: 'invoices', action: 'export', description: 'Export invoices to CSV/Excel' },
      
      // Customer CRUD
      { name: 'view_customers', resource: 'customers', action: 'view', description: 'View customers' },
      { name: 'create_customers', resource: 'customers', action: 'create', description: 'Create customers' },
      { name: 'update_customers', resource: 'customers', action: 'update', description: 'Update customers' },
      { name: 'delete_customers', resource: 'customers', action: 'delete', description: 'Delete customers' },
      
      // Invoice CRUD
      { name: 'view_invoices', resource: 'invoices', action: 'view', description: 'View invoices' },
      { name: 'create_invoices', resource: 'invoices', action: 'create', description: 'Create invoices' },
      { name: 'update_invoices', resource: 'invoices', action: 'update', description: 'Update invoices' },
      { name: 'delete_invoices', resource: 'invoices', action: 'delete', description: 'Delete invoices' },
    ];

    // Upsert permissions (insert if not exists)
    const permissionMap = new Map<string, string>();
    
    for (const perm of newPermissions) {
      // Check if permission already exists
      const existing = await db.select()
        .from(permissions)
        .where(eq(permissions.name, perm.name))
        .limit(1);
      
      if (existing.length > 0) {
        console.log(`  ✓ Permission '${perm.name}' already exists`);
        permissionMap.set(perm.name, existing[0].id);
      } else {
        const [inserted] = await db.insert(permissions)
          .values(perm)
          .returning();
        console.log(`  ✓ Created permission '${perm.name}'`);
        permissionMap.set(perm.name, inserted.id);
      }
    }

    // Define role-permission mappings
    const roleMappings = [
      {
        role: 'ADMIN',
        permissions: [
          'export_transactions', 'export_customers', 'export_invoices',
          'view_customers', 'create_customers', 'update_customers', 'delete_customers',
          'view_invoices', 'create_invoices', 'update_invoices', 'delete_invoices'
        ]
      },
      {
        role: 'admin_readonly',
        permissions: [
          'export_transactions', 'export_customers', 'export_invoices',
          'view_customers', 'view_invoices'
        ]
      },
      {
        role: 'auditor',
        permissions: [
          'export_transactions', 'export_customers', 'export_invoices',
          'view_customers', 'view_invoices'
        ]
      },
      {
        role: 'CUSTOMER',
        permissions: [
          'export_transactions', 'export_customers', 'export_invoices',
          'view_customers', 'create_customers', 'update_customers', 'delete_customers',
          'view_invoices', 'create_invoices', 'update_invoices', 'delete_invoices'
        ]
      }
    ];

    // Assign permissions to roles (skip if already assigned)
    for (const roleMapping of roleMappings) {
      console.log(`  Processing role: ${roleMapping.role}`);
      
      for (const permName of roleMapping.permissions) {
        const permId = permissionMap.get(permName);
        if (!permId) {
          console.log(`    ⚠ Permission '${permName}' not found, skipping`);
          continue;
        }

        // Check if role-permission mapping already exists
        const existing = await db.select()
          .from(rolePermissions)
          .where(
            and(
              eq(rolePermissions.role, roleMapping.role),
              eq(rolePermissions.permissionId, permId)
            )
          )
          .limit(1);

        if (existing.length > 0) {
          console.log(`    ✓ Role '${roleMapping.role}' already has '${permName}'`);
        } else {
          await db.insert(rolePermissions).values({
            role: roleMapping.role,
            permissionId: permId
          });
          console.log(`    ✓ Granted '${permName}' to '${roleMapping.role}'`);
        }
      }
    }

    // Clear permission cache to force reload
    clearPermissionCache();
    console.log('  ✓ Permission cache cleared');

    console.log('✅ Permission migration completed successfully!');
    return { success: true };
  } catch (error) {
    console.error('❌ Permission migration failed:', error);
    throw error;
  }
}

// Run migration if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  migratePermissions()
    .then(() => {
      console.log('Migration completed');
      process.exit(0);
    })
    .catch((error) => {
      console.error('Migration failed:', error);
      process.exit(1);
    });
}
