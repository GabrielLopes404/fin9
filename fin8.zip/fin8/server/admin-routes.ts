import { Router, type Request, type Response } from "express";
import { db } from "./db";
import { users, auditLogs, dataExportRequests, dataDeletionRequests, systemAlerts, permissions as permissionsTable, rolePermissions, userPermissions, activityEvents, userSessions, systemSettings } from "@shared/schema";
import { eq, desc, and, or, like, sql, isNull, isNotNull, gte, count, inArray } from "drizzle-orm";
import { createAuditLog, getClientIp, verifyAuditLogChain } from "./audit-logger";
import { requireOwner, requireAdminOrOwner, requirePermission, hasPermission, clearPermissionCache } from "./rbac";
import bcrypt from "bcryptjs";
import crypto from "crypto";

export const adminRouter = Router();

// ===== USER MANAGEMENT ENDPOINTS =====

// Get all users (with filters)
adminRouter.get("/users", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const { 
      search, 
      role, 
      suspended, 
      deleted, 
      page = 1, 
      limit = 50 
    } = req.query;

    const currentUser = req.user!;
    const offset = (Number(page) - 1) * Number(limit);

    let query = db.select({
      id: users.id,
      username: users.username,
      email: users.email,
      name: users.name,
      avatar: users.avatar,
      role: users.role,
      adminRole: users.adminRole,
      emailVerified: users.emailVerified,
      isSuspended: users.isSuspended,
      suspendedAt: users.suspendedAt,
      suspensionReason: users.suspensionReason,
      deletedAt: users.deletedAt,
      lastLoginAt: users.lastLoginAt,
      lastLoginIp: users.lastLoginIp,
      twoFactorEnabled: users.twoFactorEnabled,
      consentGiven: users.consentGiven,
      createdAt: users.createdAt,
    }).from(users);

    const conditions = [];

    if (search) {
      conditions.push(
        or(
          like(users.email, `%${search}%`),
          like(users.name, `%${search}%`),
          like(users.username, `%${search}%`)
        )
      );
    }

    if (role) {
      conditions.push(eq(users.role, role as "OWNER" | "ADMIN" | "CUSTOMER"));
    }

    if (suspended === 'true') {
      conditions.push(eq(users.isSuspended, true));
    } else if (suspended === 'false') {
      conditions.push(eq(users.isSuspended, false));
    }

    if (deleted === 'true') {
      conditions.push(isNotNull(users.deletedAt));
    } else if (deleted === 'false' || !deleted) {
      conditions.push(isNull(users.deletedAt));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions as [any, ...any[]])) as any;
    }

    const results = await query.orderBy(desc(users.createdAt)).limit(Number(limit)).offset(offset);

    // Count total for pagination
    const [{ count }] = await db.select({ count: sql<number>`count(*)::int` })
      .from(users)
      .where(conditions.length > 0 ? and(...conditions as [any, ...any[]]) : undefined);

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      action: "user_view",
      actionDetails: { count: results.length, filters: { search, role, suspended, deleted } },
      success: true,
    });

    res.json({
      users: results,
      pagination: {
        total: count,
        page: Number(page),
        limit: Number(limit),
        pages: Math.ceil(count / Number(limit)),
      },
    });
  } catch (error) {
    console.error("Error fetching users:", error);
    res.status(500).json({ message: "Failed to fetch users" });
  }
});

// Get single user details
adminRouter.get("/users/:userId", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const currentUser = req.user!;

    const [user] = await db.select().from(users).where(eq(users.id, userId));

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Remove sensitive fields
    const { password, resetToken, resetTokenExpiry, twoFactorSecret, verificationToken, ...safeUser } = user;

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      targetId: userId,
      targetType: "user",
      targetEmail: user.email,
      action: "user_view",
      actionDetails: { viewedFields: Object.keys(safeUser) },
      success: true,
    });

    res.json(safeUser);
  } catch (error) {
    console.error("Error fetching user:", error);
    res.status(500).json({ message: "Failed to fetch user" });
  }
});

// Suspend/Unsuspend user
adminRouter.post("/users/:userId/suspend", requirePermission("users", "suspend"), async (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const { suspend, reason } = req.body;
    const currentUser = req.user!;

    const [targetUser] = await db.select().from(users).where(eq(users.id, userId));

    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    // Can't suspend owner
    if (targetUser.role === 'OWNER') {
      return res.status(403).json({ message: "Cannot suspend owner user" });
    }

    await db.update(users)
      .set({
        isSuspended: suspend,
        suspendedAt: suspend ? new Date() : null,
        suspendedBy: suspend ? (currentUser as any).id : null,
        suspensionReason: suspend ? reason : null,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      targetId: userId,
      targetType: "user",
      targetEmail: targetUser.email,
      action: suspend ? "user_suspend" : "user_restore",
      reason,
      actionDetails: { suspend, reason },
      success: true,
    });

    res.json({ message: suspend ? "User suspended successfully" : "User unsuspended successfully" });
  } catch (error) {
    console.error("Error suspending user:", error);
    res.status(500).json({ message: "Failed to update user suspension status" });
  }
});

// Update user role (Owner only)
adminRouter.put("/users/:userId/role", requireOwner, async (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const { role, adminRole } = req.body;
    const currentUser = req.user!;

    const [targetUser] = await db.select().from(users).where(eq(users.id, userId));

    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    await db.update(users)
      .set({
        role,
        adminRole: role === 'ADMIN' ? adminRole : null,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));

    clearPermissionCache(userId);

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      targetId: userId,
      targetType: "user",
      targetEmail: targetUser.email,
      action: "role_assigned",
      actionDetails: { oldRole: targetUser.role, newRole: role, adminRole },
      success: true,
    });

    res.json({ message: "User role updated successfully" });
  } catch (error) {
    console.error("Error updating user role:", error);
    res.status(500).json({ message: "Failed to update user role" });
  }
});

// Soft delete user
adminRouter.delete("/users/:userId", requirePermission("users", "delete"), async (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const { reason } = req.body;
    const currentUser = req.user!;

    const [targetUser] = await db.select().from(users).where(eq(users.id, userId));

    if (!targetUser) {
      return res.status(404).json({ message: "User not found" });
    }

    // Can't delete owner
    if (targetUser.role === 'OWNER') {
      return res.status(403).json({ message: "Cannot delete owner user" });
    }

    // Soft delete (mark as deleted with 30 day retention)
    const scheduledDeletion = new Date();
    scheduledDeletion.setDate(scheduledDeletion.getDate() + 30);

    await db.update(users)
      .set({
        deletedAt: new Date(),
        deletedBy: (currentUser as any).id,
        deletionReason: reason,
        scheduledDeletionDate: scheduledDeletion,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      targetId: userId,
      targetType: "user",
      targetEmail: targetUser.email,
      action: "user_deleted",
      reason,
      actionDetails: { deletionType: "soft", scheduledDeletion },
      success: true,
    });

    res.json({ 
      message: "User soft deleted successfully",
      scheduledDeletionDate: scheduledDeletion,
    });
  } catch (error) {
    console.error("Error deleting user:", error);
    res.status(500).json({ message: "Failed to delete user" });
  }
});

// ===== AUDIT LOG ENDPOINTS =====

// Get audit logs
adminRouter.get("/audit-logs", requirePermission("audit_logs", "view"), async (req: Request, res: Response) => {
  try {
    const { 
      actorId, 
      targetId, 
      action, 
      startDate, 
      endDate,
      page = 1, 
      limit = 100 
    } = req.query;

    const currentUser = req.user!;
    const offset = (Number(page) - 1) * Number(limit);

    let query = db.select().from(auditLogs);
    const conditions = [];

    if (actorId) {
      conditions.push(eq(auditLogs.actorId, actorId as string));
    }

    if (targetId) {
      conditions.push(eq(auditLogs.targetId, targetId as string));
    }

    if (action) {
      conditions.push(eq(auditLogs.action, action as any));
    }

    if (startDate) {
      conditions.push(sql`${auditLogs.createdAt} >= ${new Date(startDate as string)}`);
    }

    if (endDate) {
      conditions.push(sql`${auditLogs.createdAt} <= ${new Date(endDate as string)}`);
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions as [any, ...any[]])) as any;
    }

    const logs = await query.orderBy(desc(auditLogs.createdAt)).limit(Number(limit)).offset(offset);

    // Count total
    const [{ count }] = await db.select({ count: sql<number>`count(*)::int` })
      .from(auditLogs)
      .where(conditions.length > 0 ? and(...conditions as [any, ...any[]]) : undefined);

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      action: "user_view",
      targetType: "audit_logs",
      actionDetails: { count: logs.length, filters: { actorId, targetId, action, startDate, endDate } },
      success: true,
    });

    res.json({
      logs,
      pagination: {
        total: count,
        page: Number(page),
        limit: Number(limit),
        pages: Math.ceil(count / Number(limit)),
      },
    });
  } catch (error) {
    console.error("Error fetching audit logs:", error);
    res.status(500).json({ message: "Failed to fetch audit logs" });
  }
});

// Verify audit log chain integrity
adminRouter.get("/audit-logs/verify", requireOwner, async (req: Request, res: Response) => {
  try {
    const { limit = 1000 } = req.query;
    const result = await verifyAuditLogChain(Number(limit));

    await createAuditLog({
      actorId: (req.user as any).id,
      actorRole: (req.user as any).role,
      actorEmail: (req.user as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      action: "user_view",
      targetType: "audit_logs",
      actionDetails: { verificationResult: result },
      success: true,
    });

    res.json(result);
  } catch (error) {
    console.error("Error verifying audit logs:", error);
    res.status(500).json({ message: "Failed to verify audit logs" });
  }
});

// ===== PERMISSIONS MANAGEMENT =====

// Get all permissions
adminRouter.get("/permissions", requirePermission("permissions", "view"), async (req: Request, res: Response) => {
  try {
    const allPermissions = await db.select().from(permissionsTable).orderBy(permissionsTable.resource, permissionsTable.action);
    res.json(allPermissions);
  } catch (error) {
    console.error("Error fetching permissions:", error);
    res.status(500).json({ message: "Failed to fetch permissions" });
  }
});

// Get role permissions
adminRouter.get("/role-permissions/:role", requirePermission("permissions", "view"), async (req: Request, res: Response) => {
  try {
    const { role } = req.params;

    const rolePerms = await db
      .select({ permission: permissionsTable })
      .from(rolePermissions)
      .innerJoin(permissionsTable, eq(rolePermissions.permissionId, permissionsTable.id))
      .where(eq(rolePermissions.role, role));

    res.json(rolePerms.map(rp => rp.permission));
  } catch (error) {
    console.error("Error fetching role permissions:", error);
    res.status(500).json({ message: "Failed to fetch role permissions" });
  }
});

// Grant permission to user (Owner only)
adminRouter.post("/users/:userId/permissions", requireOwner, async (req: Request, res: Response) => {
  try {
    const { userId } = req.params;
    const { permissionId, reason, expiresAt } = req.body;
    const currentUser = req.user!;

    await db.insert(userPermissions).values({
      userId,
      permissionId,
      grantedBy: (currentUser as any).id,
      reason,
      expiresAt: expiresAt ? new Date(expiresAt) : null,
    });

    clearPermissionCache(userId);

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      targetId: userId,
      targetType: "user",
      action: "permission_granted",
      reason,
      actionDetails: { permissionId, expiresAt },
      success: true,
    });

    res.json({ message: "Permission granted successfully" });
  } catch (error) {
    console.error("Error granting permission:", error);
    res.status(500).json({ message: "Failed to grant permission" });
  }
});

// ===== SYSTEM ALERTS =====

// Get system alerts
adminRouter.get("/alerts", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const { resolved = 'false' } = req.query;

    const alerts = await db
      .select()
      .from(systemAlerts)
      .where(eq(systemAlerts.resolved, resolved === 'true'))
      .orderBy(desc(systemAlerts.createdAt))
      .limit(100);

    res.json(alerts);
  } catch (error) {
    console.error("Error fetching alerts:", error);
    res.status(500).json({ message: "Failed to fetch alerts" });
  }
});

// Resolve alert
adminRouter.post("/alerts/:alertId/resolve", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const { alertId } = req.params;
    const currentUser = req.user!;

    await db.update(systemAlerts)
      .set({
        resolved: true,
        resolvedBy: (currentUser as any).id,
        resolvedAt: new Date(),
      })
      .where(eq(systemAlerts.id, alertId));

    res.json({ message: "Alert resolved successfully" });
  } catch (error) {
    console.error("Error resolving alert:", error);
    res.status(500).json({ message: "Failed to resolve alert" });
  }
});

// ===== DATA EXPORT REQUESTS =====

// Get export requests
adminRouter.get("/export-requests", requirePermission("data_export", "approve"), async (req: Request, res: Response) => {
  try {
    const requests = await db
      .select()
      .from(dataExportRequests)
      .orderBy(desc(dataExportRequests.createdAt))
      .limit(100);

    res.json(requests);
  } catch (error) {
    console.error("Error fetching export requests:", error);
    res.status(500).json({ message: "Failed to fetch export requests" });
  }
});

// Approve export request
adminRouter.post("/export-requests/:requestId/approve", requirePermission("data_export", "approve"), async (req: Request, res: Response) => {
  try {
    const { requestId } = req.params;
    const currentUser = req.user!;

    await db.update(dataExportRequests)
      .set({
        status: "approved",
        approvedBy: (currentUser as any).id,
        approvedAt: new Date(),
      })
      .where(eq(dataExportRequests.id, requestId));

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      targetId: requestId,
      targetType: "export_request",
      action: "data_exported",
      success: true,
    });

    res.json({ message: "Export request approved successfully" });
  } catch (error) {
    console.error("Error approving export request:", error);
    res.status(500).json({ message: "Failed to approve export request" });
  }
});

// ===== DATA DELETION REQUESTS =====

// Get deletion requests
adminRouter.get("/deletion-requests", requireOwner, async (req: Request, res: Response) => {
  try {
    const requests = await db
      .select()
      .from(dataDeletionRequests)
      .orderBy(desc(dataDeletionRequests.createdAt))
      .limit(100);

    res.json(requests);
  } catch (error) {
    console.error("Error fetching deletion requests:", error);
    res.status(500).json({ message: "Failed to fetch deletion requests" });
  }
});

// Approve deletion request
adminRouter.post("/deletion-requests/:requestId/approve", requireOwner, async (req: Request, res: Response) => {
  try {
    const { requestId } = req.params;
    const currentUser = req.user!;

    await db.update(dataDeletionRequests)
      .set({
        status: "approved",
        approvedBy: (currentUser as any).id,
        approvedAt: new Date(),
      })
      .where(eq(dataDeletionRequests.id, requestId));

    await createAuditLog({
      actorId: (currentUser as any).id,
      actorRole: (currentUser as any).role,
      actorEmail: (currentUser as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      targetId: requestId,
      targetType: "deletion_request",
      action: "data_deleted",
      success: true,
    });

    res.json({ message: "Deletion request approved successfully" });
  } catch (error) {
    console.error("Error approving deletion request:", error);
    res.status(500).json({ message: "Failed to approve deletion request" });
  }
});

// ===== STATISTICS =====

// Get admin dashboard stats
adminRouter.get("/stats", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const [totalUsers] = await db.select({ count: sql<number>`count(*)::int` }).from(users);
    const [activeUsers] = await db.select({ count: sql<number>`count(*)::int` }).from(users).where(and(isNull(users.deletedAt), eq(users.isSuspended, false)));
    const [suspendedUsers] = await db.select({ count: sql<number>`count(*)::int` }).from(users).where(eq(users.isSuspended, true));
    const [deletedUsers] = await db.select({ count: sql<number>`count(*)::int` }).from(users).where(isNotNull(users.deletedAt));
    
    const [totalAuditLogs] = await db.select({ count: sql<number>`count(*)::int` }).from(auditLogs);
    const [todayLogs] = await db.select({ count: sql<number>`count(*)::int` }).from(auditLogs).where(sql`${auditLogs.createdAt} >= CURRENT_DATE`);
    
    const [pendingExports] = await db.select({ count: sql<number>`count(*)::int` }).from(dataExportRequests).where(eq(dataExportRequests.status, "pending"));
    const [pendingDeletions] = await db.select({ count: sql<number>`count(*)::int` }).from(dataDeletionRequests).where(eq(dataDeletionRequests.status, "pending"));
    
    const [unresolvedAlerts] = await db.select({ count: sql<number>`count(*)::int` }).from(systemAlerts).where(eq(systemAlerts.resolved, false));

    res.json({
      users: {
        total: totalUsers.count,
        active: activeUsers.count,
        suspended: suspendedUsers.count,
        deleted: deletedUsers.count,
      },
      auditLogs: {
        total: totalAuditLogs.count,
        today: todayLogs.count,
      },
      requests: {
        pendingExports: pendingExports.count,
        pendingDeletions: pendingDeletions.count,
      },
      alerts: {
        unresolved: unresolvedAlerts.count,
      },
    });
  } catch (error) {
    console.error("Error fetching stats:", error);
    res.status(500).json({ message: "Failed to fetch statistics" });
  }
});

// ===== ROLES & PERMISSIONS MANAGEMENT =====

adminRouter.get("/roles/permissions", requireOwner, async (req: Request, res: Response) => {
  try {
    const allRolePerms = await db
      .select({
        role: rolePermissions.role,
        permission: permissionsTable,
      })
      .from(rolePermissions)
      .innerJoin(permissionsTable, eq(rolePermissions.permissionId, permissionsTable.id));

    const grouped = allRolePerms.reduce((acc: any, curr) => {
      const existing = acc.find((r: any) => r.role === curr.role);
      if (existing) {
        existing.permissions.push(curr.permission);
      } else {
        acc.push({ role: curr.role, permissions: [curr.permission] });
      }
      return acc;
    }, []);

    res.json(grouped);
  } catch (error) {
    console.error("Error fetching role permissions:", error);
    res.status(500).json({ message: "Failed to fetch role permissions" });
  }
});

adminRouter.get("/permissions", requireOwner, async (req: Request, res: Response) => {
  try {
    const allPerms = await db.select().from(permissionsTable).orderBy(permissionsTable.resource, permissionsTable.action);
    res.json(allPerms);
  } catch (error) {
    console.error("Error fetching permissions:", error);
    res.status(500).json({ message: "Failed to fetch permissions" });
  }
});

adminRouter.get("/roles/users", requireOwner, async (req: Request, res: Response) => {
  try {
    const allUsers = await db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        role: users.role,
        adminRole: users.adminRole,
      })
      .from(users)
      .where(isNull(users.deletedAt));

    const grouped = allUsers.reduce((acc: any, user) => {
      const role = user.adminRole || user.role;
      const existing = acc.find((r: any) => r.role === role);
      if (existing) {
        existing.users.push({ id: user.id, name: user.name, email: user.email });
        existing.count++;
      } else {
        acc.push({
          role,
          count: 1,
          users: [{ id: user.id, name: user.name, email: user.email }],
        });
      }
      return acc;
    }, []);

    res.json(grouped);
  } catch (error) {
    console.error("Error fetching users by role:", error);
    res.status(500).json({ message: "Failed to fetch users by role" });
  }
});

adminRouter.post("/roles/:role/permissions/:permissionId", requireOwner, async (req: Request, res: Response) => {
  try {
    const { role, permissionId } = req.params;

    await db.insert(rolePermissions).values({ role, permissionId });

    clearPermissionCache();

    await createAuditLog({
      actorId: (req.user as any).id,
      actorRole: (req.user as any).role,
      actorEmail: (req.user as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      action: "permission_granted",
      actionDetails: { role, permissionId },
      success: true,
    });

    res.json({ message: "Permission granted to role" });
  } catch (error) {
    console.error("Error granting permission:", error);
    res.status(500).json({ message: "Failed to grant permission" });
  }
});

adminRouter.delete("/roles/:role/permissions/:permissionId", requireOwner, async (req: Request, res: Response) => {
  try {
    const { role, permissionId } = req.params;

    await db.delete(rolePermissions).where(
      and(
        eq(rolePermissions.role, role),
        eq(rolePermissions.permissionId, permissionId)
      )
    );

    clearPermissionCache();

    await createAuditLog({
      actorId: (req.user as any).id,
      actorRole: (req.user as any).role,
      actorEmail: (req.user as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      action: "permission_revoked",
      actionDetails: { role, permissionId },
      success: true,
    });

    res.json({ message: "Permission revoked from role" });
  } catch (error) {
    console.error("Error revoking permission:", error);
    res.status(500).json({ message: "Failed to revoke permission" });
  }
});

// ===== ACTIVITY EVENTS =====

adminRouter.get("/events", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const { search, eventType, status, page = 1, limit = 50 } = req.query;
    const offset = (Number(page) - 1) * Number(limit);

    let query = db
      .select({
        event: activityEvents,
        userName: users.name,
        userEmail: users.email,
      })
      .from(activityEvents)
      .leftJoin(users, eq(activityEvents.userId, users.id));

    const conditions = [];

    if (search) {
      conditions.push(
        or(
          like(users.email, `%${search}%`),
          like(users.name, `%${search}%`)
        )
      );
    }

    if (eventType && eventType !== "all") {
      conditions.push(eq(activityEvents.eventType, eventType as any));
    }

    if (status && status !== "all") {
      conditions.push(eq(activityEvents.status, status as string));
    }

    if (conditions.length > 0) {
      query = query.where(and(...conditions as [any, ...any[]])) as any;
    }

    const results = await query
      .orderBy(desc(activityEvents.createdAt))
      .limit(Number(limit))
      .offset(offset);

    const events = results.map((r) => ({
      ...(r.event as any),
      userName: r.userName,
      userEmail: r.userEmail,
    }));

    const [{ total }] = await db
      .select({ total: sql<number>`count(*)::int` })
      .from(activityEvents);

    res.json({
      events,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        pages: Math.ceil(total / Number(limit)),
      },
    });
  } catch (error) {
    console.error("Error fetching events:", error);
    res.status(500).json({ message: "Failed to fetch events" });
  }
});

adminRouter.get("/export/events", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const events = await db
      .select()
      .from(activityEvents)
      .orderBy(desc(activityEvents.createdAt))
      .limit(10000);

    const csv = [
      "ID,Event Type,Status,User ID,IP Address,Created At",
      ...events.map((e) =>
        [e.id, e.eventType, e.status, e.userId || "", e.ipAddress || "", e.createdAt].join(",")
      ),
    ].join("\n");

    res.setHeader("Content-Type", "text/csv");
    res.setHeader("Content-Disposition", `attachment; filename=events-${Date.now()}.csv`);
    res.send(csv);
  } catch (error) {
    console.error("Error exporting events:", error);
    res.status(500).json({ message: "Failed to export events" });
  }
});

// ===== SECURITY MANAGEMENT =====

adminRouter.get("/security/sessions", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const activeSessions = await db
      .select({
        session: userSessions,
        userName: users.name,
        userEmail: users.email,
      })
      .from(userSessions)
      .innerJoin(users, eq(userSessions.userId, users.id))
      .where(
        and(
          isNull(userSessions.revokedAt),
          gte(userSessions.expiresAt, sql`NOW()`)
        )
      )
      .orderBy(desc(userSessions.lastSeenAt));

    const sessions = activeSessions.map((s) => ({
      ...(s.session as any),
      userName: s.userName,
      userEmail: s.userEmail,
    }));

    res.json(sessions);
  } catch (error) {
    console.error("Error fetching sessions:", error);
    res.status(500).json({ message: "Failed to fetch sessions" });
  }
});

adminRouter.post("/security/sessions/:sessionId/revoke", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const { sessionId } = req.params;

    await db
      .update(userSessions)
      .set({
        revokedAt: new Date(),
        revokedBy: (req.user as any).id,
        revokedReason: "Revoked by admin",
      })
      .where(eq(userSessions.id, sessionId));

    await createAuditLog({
      actorId: (req.user as any).id,
      actorRole: (req.user as any).role,
      actorEmail: (req.user as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      action: "session_revoked",
      targetId: sessionId,
      targetType: "session",
      success: true,
    });

    res.json({ message: "Session revoked successfully" });
  } catch (error) {
    console.error("Error revoking session:", error);
    res.status(500).json({ message: "Failed to revoke session" });
  }
});

adminRouter.get("/security/suspicious", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const suspicious = await db
      .select({
        id: activityEvents.id,
        userId: activityEvents.userId,
        userEmail: users.email,
        eventType: activityEvents.eventType,
        ipAddress: activityEvents.ipAddress,
        count: sql<number>`count(*)::int`,
        lastOccurrence: sql<string>`max(${activityEvents.createdAt})`,
      })
      .from(activityEvents)
      .leftJoin(users, eq(activityEvents.userId, users.id))
      .where(
        or(
          eq(activityEvents.eventType, "login_failed"),
          eq(activityEvents.eventType, "permission_denied"),
          eq(activityEvents.eventType, "unauthorized_access_attempt"),
          eq(activityEvents.eventType, "suspicious_activity_detected")
        )
      )
      .groupBy(activityEvents.id, activityEvents.userId, users.email, activityEvents.eventType, activityEvents.ipAddress)
      .having(sql`count(*) > 3`)
      .orderBy(desc(sql`max(${activityEvents.createdAt})`))
      .limit(50);

    res.json(suspicious);
  } catch (error) {
    console.error("Error fetching suspicious activity:", error);
    res.status(500).json({ message: "Failed to fetch suspicious activity" });
  }
});

// ===== SYSTEM SETTINGS =====

adminRouter.get("/settings", requireOwner, async (req: Request, res: Response) => {
  try {
    const settings = await db.select().from(systemSettings).where(isNull(systemSettings.organizationId));

    const settingsObj: Record<string, any> = {};
    settings.forEach((s) => {
      try {
        settingsObj[s.key] = JSON.parse(s.value || "null");
      } catch {
        settingsObj[s.key] = s.value;
      }
    });

    res.json(settingsObj);
  } catch (error) {
    console.error("Error fetching settings:", error);
    res.status(500).json({ message: "Failed to fetch settings" });
  }
});

adminRouter.put("/settings", requireOwner, async (req: Request, res: Response) => {
  try {
    const newSettings = req.body;

    for (const [key, value] of Object.entries(newSettings)) {
      const existing = await db
        .select()
        .from(systemSettings)
        .where(
          and(
            eq(systemSettings.key, key),
            isNull(systemSettings.organizationId)
          )
        );

      const valueStr = typeof value === "object" ? JSON.stringify(value) : String(value);

      if (existing.length > 0) {
        await db
          .update(systemSettings)
          .set({
            value: valueStr,
            updatedBy: (req.user as any).id,
            updatedAt: new Date(),
          })
          .where(eq(systemSettings.id, existing[0].id));
      } else {
        await db.insert(systemSettings).values({
          key,
          value: valueStr,
          updatedBy: (req.user as any).id,
        });
      }
    }

    await createAuditLog({
      actorId: (req.user as any).id,
      actorRole: (req.user as any).role,
      actorEmail: (req.user as any).email,
      actorIp: getClientIp(req),
      actorUserAgent: req.headers['user-agent'],
      action: "settings_changed",
      actionDetails: { keys: Object.keys(newSettings) },
      success: true,
    });

    res.json({ message: "Settings updated successfully" });
  } catch (error) {
    console.error("Error updating settings:", error);
    res.status(500).json({ message: "Failed to update settings" });
  }
});

// ===== ANALYTICS =====

adminRouter.get("/analytics", requireAdminOrOwner, async (req: Request, res: Response) => {
  try {
    const [totalUsers] = await db.select({ count: sql<number>`count(*)::int` }).from(users);
    const [activeToday] = await db.select({ count: sql<number>`count(DISTINCT ${users.id})::int` })
      .from(activityEvents)
      .innerJoin(users, eq(activityEvents.userId, users.id))
      .where(gte(activityEvents.createdAt, sql`CURRENT_DATE`));
    
    const [newThisWeek] = await db.select({ count: sql<number>`count(*)::int` })
      .from(users)
      .where(gte(users.createdAt, sql`CURRENT_DATE - INTERVAL '7 days'`));

    const [totalEvents] = await db.select({ count: sql<number>`count(*)::int` }).from(activityEvents);

    const userGrowth = await db
      .select({
        date: sql<string>`date_trunc('day', ${users.createdAt})::date`,
        new: sql<number>`count(*)::int`,
      })
      .from(users)
      .where(gte(users.createdAt, sql`CURRENT_DATE - INTERVAL '30 days'`))
      .groupBy(sql`date_trunc('day', ${users.createdAt})`)
      .orderBy(sql`date_trunc('day', ${users.createdAt})`);

    let cumulative = 0;
    const growthWithTotal = userGrowth.map((g) => {
      cumulative += g.new;
      return { date: g.date, new: g.new, total: cumulative };
    });

    const topActions = await db
      .select({
        action: activityEvents.eventType,
        count: sql<number>`count(*)::int`,
      })
      .from(activityEvents)
      .groupBy(activityEvents.eventType)
      .orderBy(desc(sql`count(*)`))
      .limit(5);

    const [activeUsers] = await db.select({ count: sql<number>`count(DISTINCT ${users.id})::int` })
      .from(activityEvents)
      .innerJoin(users, eq(activityEvents.userId, users.id))
      .where(gte(activityEvents.createdAt, sql`CURRENT_DATE - INTERVAL '7 days'`));

    const inactiveUsers = totalUsers.count - activeUsers.count;

    const loginsByHour = await db
      .select({
        hour: sql<string>`extract(hour from ${activityEvents.createdAt})::text`,
        logins: sql<number>`count(*)::int`,
      })
      .from(activityEvents)
      .where(
        and(
          eq(activityEvents.eventType, "login_success"),
          gte(activityEvents.createdAt, sql`CURRENT_DATE`)
        )
      )
      .groupBy(sql`extract(hour from ${activityEvents.createdAt})`)
      .orderBy(sql`extract(hour from ${activityEvents.createdAt})`);

    res.json({
      stats: {
        totalUsers: totalUsers.count,
        activeToday: activeToday.count,
        newThisWeek: newThisWeek.count,
        totalEvents: totalEvents.count,
      },
      userGrowth: growthWithTotal,
      topActions,
      userActivity: {
        active: activeUsers.count,
        inactive: inactiveUsers,
      },
      loginsByHour,
    });
  } catch (error) {
    console.error("Error fetching analytics:", error);
    res.status(500).json({ message: "Failed to fetch analytics" });
  }
});
