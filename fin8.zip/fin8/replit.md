# LUCREI - Financial Management Platform

## Overview

LUCREI is a comprehensive financial management and invoicing platform designed for small to medium-sized businesses (SMEs) in Brazil. The system provides complete control over finances, customer relationships, invoicing, and business metrics with enterprise-level security features including role-based access control (RBAC), immutable audit logging, and LGPD (Brazilian data protection law) compliance.

The application is built as a full-stack monorepo with a React frontend and Express backend, using PostgreSQL for data persistence and Stripe for payment processing.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Application Structure

**Monorepo Organization:**
- `client/` - React frontend application (Vite-based SPA)
- `server/` - Express.js backend API
- `shared/` - Shared TypeScript types and database schema (Drizzle ORM)
- `migrations/` - Database migration files
- `tests/` - Unit, integration, and E2E tests

### Frontend Architecture

**Technology Stack:**
- **Framework:** React 18 with TypeScript
- **Routing:** Wouter (lightweight alternative to React Router)
- **State Management:** TanStack Query (React Query) for server state
- **UI Components:** Shadcn/ui (Radix UI primitives + Tailwind CSS)
- **Styling:** Tailwind CSS with custom theme system supporting light/dark modes
- **Build Tool:** Vite for fast development and optimized production builds
- **Internationalization:** i18next for multi-language support
- **Error Tracking:** Sentry for production error monitoring

**Key Design Patterns:**
- Code-splitting with lazy loading for non-critical routes
- Protected routes with authentication guards
- Custom hooks for auth, toasts, and theme management
- Error boundaries for graceful error handling
- Responsive design with mobile-first approach

### Backend Architecture

**Technology Stack:**
- **Runtime:** Node.js with TypeScript
- **Framework:** Express.js
- **Database ORM:** Drizzle ORM with PostgreSQL (Neon serverless)
- **Authentication:** Passport.js with local strategy + session-based auth
- **Session Store:** PostgreSQL-based sessions (connect-pg-simple)
- **Validation:** Zod schemas for request/response validation
- **Security:** Helmet, CORS, rate limiting, CSRF protection

**API Design:**
- RESTful endpoints under `/api/*` prefix
- Separate admin routes under `/api/admin/*` with enhanced permissions
- Consistent error handling and validation
- Pagination support for list endpoints
- Comprehensive logging with Winston

**Authentication Flow:**
1. User registers with email/password + organization creation
2. Password hashed with bcrypt (12 rounds)
3. Email verification token generated (optional verification)
4. Session created and stored in PostgreSQL
5. Auto-login after successful registration
6. Optional 2FA with TOTP (authenticator apps)

**Authorization (RBAC):**
- **Roles:** OWNER, ADMIN, CUSTOMER, plus admin sub-roles (admin_full, admin_readonly, auditor, support)
- **Permission System:** Resource-action based permissions stored in database
- **Permission Caching:** In-memory cache (5-minute TTL) for performance
- **Middleware:** `requireOwner`, `requireAdminOrOwner`, `requirePermission` guards
- **Audit Trail:** All permission checks and role changes logged

### Database Architecture

**ORM Choice:** Drizzle ORM selected for type-safety, performance, and SQL-like syntax

**Migration Strategy:**
- Development: `db:push` for rapid schema iteration
- Production: `db:generate` + `db:migrate` for versioned migrations
- Migration files stored in `migrations/` directory

**Core Tables:**
- `users` - User accounts with password hashes, roles, 2FA settings
- `organizations` - Multi-tenant organization data
- `customers` - Customer/client records
- `invoices` - Invoice management with status tracking
- `transactions` - Financial transactions (income/expense)
- `subscriptions` - Stripe subscription integration
- `categories`, `bank_accounts`, `cost_centers`, `tags` - Financial organization
- `audit_logs` - Immutable audit trail with hash chaining
- `user_permissions`, `role_permissions` - RBAC permission system
- `user_sessions` - Active session tracking
- `consent_records` - LGPD consent tracking
- `data_export_requests`, `data_deletion_requests` - LGPD compliance

**Security Features:**
- Immutable audit logs with SHA-256 hash chaining
- Soft deletes for user records (LGPD compliance)
- Encrypted sensitive fields (2FA secrets, tokens)
- Session management with device tracking
- IP address and geolocation logging

### External Dependencies

**Database:**
- **Provider:** Neon (serverless PostgreSQL)
- **Connection:** WebSocket-based with connection pooling
- **Environment Variable:** `DATABASE_URL`

**Payment Processing:**
- **Service:** Stripe
- **Integration:** Subscription management, checkout sessions, webhooks
- **Environment Variables:** `STRIPE_SECRET_KEY`, price IDs for plans

**Email Service:**
- **Provider:** Resend
- **Use Cases:** Email verification, password reset, invoice notifications
- **Environment Variable:** `RESEND_API_KEY`

**Error Monitoring:**
- **Service:** Sentry
- **Coverage:** Frontend and backend error tracking
- **Environment Variable:** `SENTRY_DSN`

**Development Tools:**
- **Replit Plugins:** Cartographer (code navigation), dev banner, runtime error modal
- **Testing:** Vitest (unit/integration), Playwright (E2E), Happy DOM (component tests)

**Security & Monitoring:**
- **Rate Limiting:** express-rate-limit with different limits per endpoint type
- **Metrics:** Prometheus client for HTTP/DB metrics
- **Health Checks:** `/health`, `/health/live`, `/health/ready` endpoints
- **CSRF Protection:** Token-based CSRF prevention

**File Processing:**
- **Upload:** Multer with size limits and MIME type validation
- **Parsing:** CSV import (csv-parse), Excel (XLSX), OFX bank statements
- **PDF Generation:** PDFKit for financial reports (DRE)
- **Document Validation:** CPF/CNPJ validation for Brazilian documents

**Session Management:**
- **Store:** PostgreSQL-based session storage
- **Features:** Multi-device tracking, session revocation, activity monitoring
- **Security:** HTTP-only cookies, secure flag in production, SameSite=strict