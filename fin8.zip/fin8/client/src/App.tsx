import { lazy, Suspense } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { ErrorBoundary } from "react-error-boundary";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "next-themes";
import { ErrorFallback, RouteErrorFallback } from "@/components/ErrorFallback";
import { logError } from "@/lib/errorLogger";
import { Loader2 } from "lucide-react";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/components/ProtectedRoute";

// Eager load critical pages (Landing, Login, Register)
import LandingPage from "@/pages/LandingPage";
import LoginPage from "@/pages/LoginPage";
import RegisterPage from "@/pages/RegisterPage";

// Lazy load all other pages for better performance
const ForgotPasswordPage = lazy(() => import("@/pages/ForgotPasswordPage"));
const ResetPasswordPage = lazy(() => import("@/pages/ResetPasswordPage"));
const DashboardPage = lazy(() => import("@/pages/DashboardPage"));
const CustomersPage = lazy(() => import("@/pages/CustomersPage"));
const InvoicesPage = lazy(() => import("@/pages/InvoicesPage"));
const TransactionsPage = lazy(() => import("@/pages/TransactionsPage"));
const ReportsPage = lazy(() => import("@/pages/ReportsPage"));
const ImportsPage = lazy(() => import("@/pages/ImportsPage"));
const ReconciliationsPage = lazy(() => import("@/pages/ReconciliationsPage"));
const ProfilePage = lazy(() => import("@/pages/ProfilePage"));
const AccountsPage = lazy(() => import("@/pages/AccountsPage"));
const CategoriesPage = lazy(() => import("@/pages/CategoriesPage"));
const CostCentersPage = lazy(() => import("@/pages/CostCentersPage"));
const BankAccountsPage = lazy(() => import("@/pages/BankAccountsPage"));
const DocumentsPage = lazy(() => import("@/pages/DocumentsPage"));
const TagsPage = lazy(() => import("@/pages/TagsPage"));
const ExportPage = lazy(() => import("@/pages/ExportPage"));
const SubscriptionPage = lazy(() => import("@/pages/SubscriptionPage"));
const SubscribePage = lazy(() => import("@/pages/SubscribePage"));
const SubscriptionSuccessPage = lazy(() => import("@/pages/SubscriptionSuccessPage"));
const SubscriptionCancelPage = lazy(() => import("@/pages/SubscriptionCancelPage"));
const PricingPage = lazy(() => import("@/pages/PricingPage"));
const RecursosPage = lazy(() => import("@/pages/RecursosPage"));
const IntegracoesPage = lazy(() => import("@/pages/IntegracoesPage"));
const APIDocsPage = lazy(() => import("@/pages/APIDocsPage"));
const SobrePage = lazy(() => import("@/pages/SobrePage"));
const BlogPage = lazy(() => import("@/pages/BlogPage"));
const CarreirasPage = lazy(() => import("@/pages/CarreirasPage"));
const ContatoPage = lazy(() => import("@/pages/ContatoPage"));
const PrivacidadePage = lazy(() => import("@/pages/PrivacidadePage"));
const TermosPage = lazy(() => import("@/pages/TermosPage"));
const SegurancaPage = lazy(() => import("@/pages/SegurancaPage"));
const LGPDPage = lazy(() => import("@/pages/LGPDPage"));
const HelpVideoaulasPage = lazy(() => import("@/pages/HelpVideoaulasPage"));
const HelpGuiasPage = lazy(() => import("@/pages/HelpGuiasPage"));
const HelpDicasPage = lazy(() => import("@/pages/HelpDicasPage"));
const HelpFeedbackPage = lazy(() => import("@/pages/HelpFeedbackPage"));
const HelpSuportePage = lazy(() => import("@/pages/HelpSuportePage"));
const AdminDashboardPage = lazy(() => import("@/pages/AdminDashboardPage"));
const AdminUsersPage = lazy(() => import("@/pages/AdminUsersPage"));
const AdminAuditPage = lazy(() => import("@/pages/AdminAuditPage"));
const AdminRolesPage = lazy(() => import("@/pages/AdminRolesPage"));
const AdminEventsPage = lazy(() => import("@/pages/AdminEventsPage"));
const AdminSecurityPage = lazy(() => import("@/pages/AdminSecurityPage"));
const AdminSettingsPage = lazy(() => import("@/pages/AdminSettingsPage"));
const AdminAnalyticsPage = lazy(() => import("@/pages/AdminAnalyticsPage"));
const AdminHealthPage = lazy(() => import("@/pages/AdminHealthPage"));
const NotFound = lazy(() => import("@/pages/not-found"));

// Loading fallback component
function PageLoader() {
  return (
    <div className="flex items-center justify-center min-h-screen">
      <Loader2 className="w-8 h-8 animate-spin text-primary" />
    </div>
  );
}

function RouteWrapper({ component: Component }: { component: React.ComponentType }) {
  return (
    <ErrorBoundary FallbackComponent={RouteErrorFallback} onError={logError}>
      <Suspense fallback={<PageLoader />}>
        <Component />
      </Suspense>
    </ErrorBoundary>
  );
}

function Router() {
  return (
    <Switch>
      {/* Eager loaded routes (critical paths) */}
      <Route path="/" component={LandingPage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/register" component={RegisterPage} />
      
      {/* Lazy loaded routes (code-split for performance) */}
      <Route path="/forgot-password">
        <Suspense fallback={<PageLoader />}>
          <ForgotPasswordPage />
        </Suspense>
      </Route>
      <Route path="/reset-password">
        <Suspense fallback={<PageLoader />}>
          <ResetPasswordPage />
        </Suspense>
      </Route>
      <Route path="/app/dashboard">
        <ProtectedRoute>
          <RouteWrapper component={DashboardPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/transactions">
        <ProtectedRoute>
          <RouteWrapper component={TransactionsPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/customers">
        <ProtectedRoute>
          <RouteWrapper component={CustomersPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/reports">
        <ProtectedRoute>
          <RouteWrapper component={ReportsPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/imports">
        <ProtectedRoute>
          <RouteWrapper component={ImportsPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/reconciliations">
        <ProtectedRoute>
          <RouteWrapper component={ReconciliationsPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/invoices">
        <ProtectedRoute>
          <RouteWrapper component={InvoicesPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/profile">
        <ProtectedRoute>
          <RouteWrapper component={ProfilePage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/settings">
        <ProtectedRoute>
          <RouteWrapper component={ProfilePage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/accounts">
        <ProtectedRoute>
          <RouteWrapper component={AccountsPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/categories">
        <ProtectedRoute>
          <RouteWrapper component={CategoriesPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/cost-centers">
        <ProtectedRoute>
          <RouteWrapper component={CostCentersPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/bank-accounts">
        <ProtectedRoute>
          <RouteWrapper component={BankAccountsPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/documents">
        <ProtectedRoute>
          <RouteWrapper component={DocumentsPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/tags">
        <ProtectedRoute>
          <RouteWrapper component={TagsPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/export">
        <ProtectedRoute>
          <RouteWrapper component={ExportPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/subscription">
        <ProtectedRoute>
          <RouteWrapper component={SubscriptionPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/pricing">
        <ProtectedRoute>
          <RouteWrapper component={PricingPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/pricing">
        <RouteWrapper component={PricingPage} />
      </Route>
      <Route path="/subscribe">
        <RouteWrapper component={SubscribePage} />
      </Route>
      <Route path="/subscription/success">
        <RouteWrapper component={SubscriptionSuccessPage} />
      </Route>
      <Route path="/subscription/cancel">
        <RouteWrapper component={SubscriptionCancelPage} />
      </Route>
      <Route path="/recursos">
        <RouteWrapper component={RecursosPage} />
      </Route>
      <Route path="/integracoes">
        <RouteWrapper component={IntegracoesPage} />
      </Route>
      <Route path="/api-docs">
        <RouteWrapper component={APIDocsPage} />
      </Route>
      <Route path="/sobre">
        <RouteWrapper component={SobrePage} />
      </Route>
      <Route path="/blog">
        <RouteWrapper component={BlogPage} />
      </Route>
      <Route path="/carreiras">
        <RouteWrapper component={CarreirasPage} />
      </Route>
      <Route path="/contato">
        <RouteWrapper component={ContatoPage} />
      </Route>
      <Route path="/privacidade">
        <RouteWrapper component={PrivacidadePage} />
      </Route>
      <Route path="/termos">
        <RouteWrapper component={TermosPage} />
      </Route>
      <Route path="/seguranca">
        <RouteWrapper component={SegurancaPage} />
      </Route>
      <Route path="/lgpd">
        <RouteWrapper component={LGPDPage} />
      </Route>
      <Route path="/app/help/videoaulas">
        <ProtectedRoute>
          <RouteWrapper component={HelpVideoaulasPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/help/guias">
        <ProtectedRoute>
          <RouteWrapper component={HelpGuiasPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/help/dicas">
        <ProtectedRoute>
          <RouteWrapper component={HelpDicasPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/help/feedback">
        <ProtectedRoute>
          <RouteWrapper component={HelpFeedbackPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/app/help/suporte">
        <ProtectedRoute>
          <RouteWrapper component={HelpSuportePage} />
        </ProtectedRoute>
      </Route>
      <Route path="/admin">
        <ProtectedRoute requireAdmin>
          <RouteWrapper component={AdminDashboardPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/users">
        <ProtectedRoute requireAdmin>
          <RouteWrapper component={AdminUsersPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/audit">
        <ProtectedRoute requireAdmin>
          <RouteWrapper component={AdminAuditPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/roles">
        <ProtectedRoute requireAdmin>
          <RouteWrapper component={AdminRolesPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/events">
        <ProtectedRoute requireAdmin>
          <RouteWrapper component={AdminEventsPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/security">
        <ProtectedRoute requireAdmin>
          <RouteWrapper component={AdminSecurityPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/settings">
        <ProtectedRoute requireAdmin>
          <RouteWrapper component={AdminSettingsPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/analytics">
        <ProtectedRoute requireAdmin>
          <RouteWrapper component={AdminAnalyticsPage} />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/health">
        <ProtectedRoute requireAdmin>
          <RouteWrapper component={AdminHealthPage} />
        </ProtectedRoute>
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary FallbackComponent={ErrorFallback} onError={logError}>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <AuthProvider>
            <TooltipProvider>
              <Toaster />
              <Router />
            </TooltipProvider>
          </AuthProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
