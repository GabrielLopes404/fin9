import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Shield,
  AlertTriangle,
  LogOut,
  ShieldAlert,
  Clock,
  Globe,
} from "lucide-react";
import { format } from "date-fns";

interface ActiveSession {
  id: string;
  userId: string;
  userName: string;
  userEmail: string;
  ipAddress: string | null;
  userAgent: string | null;
  issuedAt: string;
  lastSeenAt: string;
  isElevated: boolean;
}

interface SuspiciousActivity {
  id: string;
  userId: string | null;
  userEmail: string | null;
  eventType: string;
  ipAddress: string | null;
  count: number;
  lastOccurrence: string;
}

export default function AdminSecurityPage() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [sessions, setSessions] = useState<ActiveSession[]>([]);
  const [suspicious, setSuspicious] = useState<SuspiciousActivity[]>([]);
  const [loading, setLoading] = useState(true);
  const [revokeSession, setRevokeSession] = useState<ActiveSession | null>(null);

  useEffect(() => {
    if (!user || (user.role !== "OWNER" && user.role !== "ADMIN")) {
      setLocation("/admin");
      return;
    }
    loadData();
    const interval = setInterval(loadData, 30000);
    return () => clearInterval(interval);
  }, [user]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [sessionsRes, suspiciousRes] = await Promise.all([
        fetch("/api/admin/security/sessions", { credentials: "include" }),
        fetch("/api/admin/security/suspicious", { credentials: "include" }),
      ]);

      if (sessionsRes.ok) {
        const data = await sessionsRes.json();
        setSessions(data);
      }

      if (suspiciousRes.ok) {
        const data = await suspiciousRes.json();
        setSuspicious(data);
      }
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao carregar dados de segurança",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRevokeSession = async (sessionId: string) => {
    try {
      const res = await fetch(`/api/admin/security/sessions/${sessionId}/revoke`, {
        method: "POST",
        credentials: "include",
      });

      if (!res.ok) throw new Error("Failed to revoke session");

      toast({
        title: "Sucesso",
        description: "Sessão encerrada com sucesso",
      });

      loadData();
    } catch (error) {
      toast({
        title: "Erro",
        description: "Falha ao encerrar sessão",
        variant: "destructive",
      });
    } finally {
      setRevokeSession(null);
    }
  };

  if (!user || (user.role !== "OWNER" && user.role !== "ADMIN")) {
    return null;
  }

  return (
    <div className="container mx-auto py-8 px-4 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-2">
          <Shield className="h-8 w-8" />
          Painel de Segurança
        </h1>
        <p className="text-muted-foreground">
          Monitore sessões ativas, tentativas suspeitas e atividades de risco
        </p>
      </div>

      <div className="grid gap-6 mb-6 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Sessões Ativas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{sessions.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Usuários conectados agora
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Atividades Suspeitas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{suspicious.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Eventos que requerem atenção
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Sessões Elevadas (2FA)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {sessions.filter((s) => s.isElevated).length}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Com autenticação de dois fatores
            </p>
          </CardContent>
        </Card>
      </div>

      {suspicious.length > 0 && (
        <Card className="mb-6 border-orange-200 dark:border-orange-900">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-orange-700 dark:text-orange-400">
              <AlertTriangle className="h-5 w-5" />
              Atividades Suspeitas Detectadas
            </CardTitle>
            <CardDescription>
              Eventos de segurança que requerem investigação
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Tipo de Evento</TableHead>
                  <TableHead>Usuário/IP</TableHead>
                  <TableHead>Ocorrências</TableHead>
                  <TableHead>Última Ocorrência</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {suspicious.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>
                      <Badge variant="destructive">
                        {item.eventType.replace(/_/g, " ")}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {item.userEmail || item.ipAddress || "Desconhecido"}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{item.count} vezes</Badge>
                    </TableCell>
                    <TableCell>
                      {format(new Date(item.lastOccurrence), "dd/MM/yyyy HH:mm")}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Sessões Ativas</CardTitle>
              <CardDescription>
                Gerencie sessões de usuários conectados
              </CardDescription>
            </div>
            <Button variant="outline" onClick={loadData} size="sm">
              Atualizar
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Usuário</TableHead>
                  <TableHead>IP</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Última Atividade</TableHead>
                  <TableHead>Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sessions.length > 0 ? (
                  sessions.map((session) => (
                    <TableRow key={session.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{session.userName || "N/A"}</div>
                          <div className="text-sm text-muted-foreground">{session.userEmail}</div>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-sm">
                        {session.ipAddress || "N/A"}
                      </TableCell>
                      <TableCell>
                        {session.isElevated ? (
                          <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
                            <ShieldAlert className="h-3 w-3 mr-1" />
                            2FA Ativo
                          </Badge>
                        ) : (
                          <Badge variant="secondary">Normal</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 text-sm">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          {format(new Date(session.lastSeenAt), "HH:mm:ss")}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => setRevokeSession(session)}
                        >
                          <LogOut className="h-4 w-4 mr-2" />
                          Encerrar
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      Nenhuma sessão ativa no momento
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={!!revokeSession} onOpenChange={() => setRevokeSession(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Encerrar Sessão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja encerrar a sessão de{" "}
              <strong>{revokeSession?.userEmail}</strong>? O usuário precisará fazer login novamente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => revokeSession && handleRevokeSession(revokeSession.id)}
            >
              Encerrar Sessão
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
