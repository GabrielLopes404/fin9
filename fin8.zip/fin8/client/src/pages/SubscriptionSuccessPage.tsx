import { useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Sparkles, ArrowRight, Mail, CreditCard } from "lucide-react";
import { motion } from "framer-motion";
import confetti from "canvas-confetti";

export default function SubscriptionSuccessPage() {
  const [, setLocation] = useLocation();

  const { data: user } = useQuery({
    queryKey: ["/api/user"],
  });

  const { data: subscription } = useQuery({
    queryKey: ["/api/subscription"],
    retry: 3,
    retryDelay: 1000,
  });

  useEffect(() => {
    const duration = 3000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

    function randomInRange(min: number, max: number) {
      return Math.random() * (max - min) + min;
    }

    const interval = setInterval(function() {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 }
      });
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 }
      });
    }, 250);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-background via-green-500/5 to-background">
      <div className="max-w-4xl mx-auto px-4 py-16 flex-1 flex items-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, type: "spring" }}
          className="w-full"
        >
          <Card className="p-12 bg-gradient-to-br from-background/80 to-background/40 backdrop-blur-xl border-green-500/20 text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="mb-8 inline-block"
            >
              <div className="relative">
                <div className="absolute inset-0 bg-green-500/20 blur-3xl rounded-full" />
                <div className="relative h-32 w-32 mx-auto rounded-full bg-gradient-to-br from-green-500 to-emerald-600 flex items-center justify-center shadow-2xl">
                  <CheckCircle2 className="h-16 w-16 text-white" strokeWidth={3} />
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              <Badge className="mb-6 bg-gradient-to-r from-green-600 to-emerald-600 border-0 text-white px-6 py-2">
                <Sparkles className="h-4 w-4 mr-2 inline" />
                Assinatura Confirmada
              </Badge>

              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                Parabéns{user?.name ? `, ${user.name.split(' ')[0]}` : ''}! 🎉
              </h1>
              
              <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
                Sua assinatura foi ativada com sucesso. Agora você tem acesso completo a todos os recursos do seu plano!
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.6 }}
              className="grid md:grid-cols-3 gap-6 mb-12 max-w-3xl mx-auto"
            >
              <Card className="p-6 bg-gradient-to-br from-green-500/10 to-emerald-500/5 border-green-500/20">
                <CreditCard className="h-10 w-10 text-green-600 mb-3 mx-auto" />
                <h3 className="font-bold mb-2">Pagamento Processado</h3>
                <p className="text-sm text-muted-foreground">
                  Seu pagamento foi confirmado com sucesso
                </p>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-blue-500/10 to-cyan-500/5 border-blue-500/20">
                <Mail className="h-10 w-10 text-blue-600 mb-3 mx-auto" />
                <h3 className="font-bold mb-2">Email Enviado</h3>
                <p className="text-sm text-muted-foreground">
                  Verifique sua caixa de entrada para o recibo
                </p>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-violet-500/10 to-fuchsia-500/5 border-violet-500/20">
                <Sparkles className="h-10 w-10 text-violet-600 mb-3 mx-auto" />
                <h3 className="font-bold mb-2">Acesso Liberado</h3>
                <p className="text-sm text-muted-foreground">
                  Todos os recursos estão disponíveis agora
                </p>
              </Card>
            </motion.div>

            {subscription && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.7 }}
                className="p-6 bg-muted/50 rounded-lg mb-8 max-w-2xl mx-auto"
              >
                <h3 className="font-bold mb-4 text-left">Detalhes da Assinatura:</h3>
                <div className="space-y-2 text-left">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Plano:</span>
                    <span className="font-semibold capitalize">{subscription.planType}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Status:</span>
                    <Badge className="bg-green-600">
                      {subscription.status === 'active' ? 'Ativo' : subscription.status}
                    </Badge>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Valor:</span>
                    <span className="font-semibold">R$ {subscription.amount}</span>
                  </div>
                  {subscription.currentPeriodEnd && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Próxima cobrança:</span>
                      <span className="font-semibold">
                        {new Date(subscription.currentPeriodEnd).toLocaleDateString('pt-BR')}
                      </span>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <Button
                size="lg"
                className="bg-gradient-to-r from-violet-600 via-fuchsia-600 to-violet-600 shadow-xl"
                onClick={() => setLocation("/app/dashboard")}
              >
                Ir para o Dashboard
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>

              <Button
                size="lg"
                variant="outline"
                onClick={() => setLocation("/app/subscription")}
              >
                Gerenciar Assinatura
              </Button>
            </motion.div>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1, duration: 0.6 }}
              className="text-sm text-muted-foreground mt-8"
            >
              Precisa de ajuda? Entre em contato com nosso{" "}
              <button
                onClick={() => setLocation("/contato")}
                className="text-violet-600 hover:underline font-semibold"
              >
                suporte
              </button>
            </motion.p>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
