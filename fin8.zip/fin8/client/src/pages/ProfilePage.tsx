import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useTranslation } from "react-i18next";
import AppLayout from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Building, User as UserIcon, Bell, Lock, Palette, Mail, Phone, MapPin, Shield, Smartphone, Laptop, Tablet, Monitor, X, Copy, CheckCircle2, Sun, Moon, CreditCard, Calendar } from "lucide-react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { useTheme } from "next-themes";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PasswordInput } from "@/components/ui/password-input";
import { maskPhone, maskZipCode, fetchAddressFromCEP } from "@/lib/masks";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Organization {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  document: string | null;
  address: string | null;
  city: string | null;
  state: string | null;
  zipCode: string | null;
  planType: string | null;
  createdAt: string;
}

interface User {
  id: string;
  name: string;
  email: string;
  passwordChangedAt: string | null;
}

interface TwoFactorStatus {
  enabled: boolean;
  configured: boolean;
}

interface ActiveSession {
  sid: string;
  device: string;
  browser: string;
  os: string;
  ipAddress: string;
  lastActivity: string;
  current: boolean;
}

interface UserPreferences {
  emailNotifications: boolean;
  activityAlerts: boolean;
  themePreference: string;
  colorScheme: string;
  language: string;
  weeklyReports: boolean;
}

interface Subscription {
  id: string;
  status: string;
  planType: string | null;
  currentPeriodEnd: string | null;
  amount: string | null;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.05 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
    transition: { type: "spring", stiffness: 100 }
  }
};

type Section = "personal" | "organization" | "preferences" | "notifications" | "security" | "subscription";

export default function ProfilePage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { theme, setTheme } = useTheme();
  const { t, i18n } = useTranslation();
  const [csrfToken, setCsrfToken] = useState("");
  const [activeSection, setActiveSection] = useState<Section>("personal");
  
  const [orgFormData, setOrgFormData] = useState({
    name: "",
    email: "",
    phone: "",
    document: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
  });

  const [preferences, setPreferences] = useState({
    themePreference: "system",
    language: "pt-BR",
    colorScheme: "purple",
    emailNotifications: true,
    activityAlerts: true,
    weeklyReports: true,
  });

  const [isPasswordDialogOpen, setIsPasswordDialogOpen] = useState(false);
  const [is2FADialogOpen, setIs2FADialogOpen] = useState(false);
  const [isSessionsDialogOpen, setIsSessionsDialogOpen] = useState(false);
  const [passwordFormData, setPasswordFormData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [qrCodeUrl, setQrCodeUrl] = useState("");
  const [twoFactorToken, setTwoFactorToken] = useState("");
  const [disable2FAToken, setDisable2FAToken] = useState("");
  const [copied, setCopied] = useState(false);

  const handlePhoneChange = (value: string) => {
    setOrgFormData(prev => ({ ...prev, phone: maskPhone(value) }));
  };

  const handleZipCodeChange = async (value: string) => {
    const masked = maskZipCode(value);
    setOrgFormData(prev => ({ ...prev, zipCode: masked }));
    
    if (masked.replace(/\D/g, '').length === 8) {
      const addressData = await fetchAddressFromCEP(masked);
      if (addressData) {
        setOrgFormData(prev => ({
          ...prev,
          address: addressData.logradouro || prev.address,
          city: addressData.localidade || prev.city,
          state: addressData.uf || prev.state,
        }));
      }
    }
  };

  useEffect(() => {
    fetch("/api/csrf-token", { credentials: "include" })
      .then((res) => res.json())
      .then((data) => setCsrfToken(data.csrfToken))
      .catch(() => {});
  }, []);

  const { data: currentUser, isLoading: isLoadingUser } = useQuery<User>({
    queryKey: ["/api/user"],
    queryFn: async () => {
      const res = await fetch("/api/user", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch user");
      return res.json();
    },
  });

  const { data: organization, isLoading: isLoadingOrg } = useQuery<Organization>({
    queryKey: ["/api/organizations/current"],
    queryFn: async () => {
      const res = await fetch("/api/organizations/current", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch organization");
      return res.json();
    },
  });

  const { data: twoFactorStatus, refetch: refetch2FAStatus } = useQuery<TwoFactorStatus>({
    queryKey: ["/api/user/2fa/status"],
    queryFn: async () => {
      const res = await fetch("/api/user/2fa/status", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch 2FA status");
      return res.json();
    },
  });

  const { data: activeSessions, refetch: refetchSessions } = useQuery<ActiveSession[]>({
    queryKey: ["/api/user/sessions"],
    queryFn: async () => {
      const res = await fetch("/api/user/sessions", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch sessions");
      return res.json();
    },
  });

  const { data: userPreferences } = useQuery<UserPreferences>({
    queryKey: ["/api/user/preferences"],
    queryFn: async () => {
      const res = await fetch("/api/user/preferences", { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch preferences");
      return res.json();
    },
  });

  const { data: subscription } = useQuery<Subscription>({
    queryKey: ["/api/subscription"],
    queryFn: async () => {
      const res = await fetch("/api/subscription", { credentials: "include" });
      if (!res.ok) return null;
      return res.json();
    },
  });

  useEffect(() => {
    if (organization) {
      setOrgFormData({
        name: organization.name || "",
        email: organization.email || "",
        phone: organization.phone || "",
        document: organization.document || "",
        address: organization.address || "",
        city: organization.city || "",
        state: organization.state || "",
        zipCode: organization.zipCode || "",
      });
    }
  }, [organization]);

  useEffect(() => {
    if (userPreferences) {
      setPreferences({
        themePreference: userPreferences.themePreference || "system",
        language: userPreferences.language || "pt-BR",
        colorScheme: userPreferences.colorScheme || "purple",
        emailNotifications: userPreferences.emailNotifications ?? true,
        activityAlerts: userPreferences.activityAlerts ?? true,
        weeklyReports: userPreferences.weeklyReports ?? true,
      });
      if (userPreferences.themePreference) {
        setTheme(userPreferences.themePreference);
      }
    }
  }, [userPreferences, setTheme]);

  useEffect(() => {
    const colorMap: Record<string, string> = {
      purple: '270 91% 65%',
      blue: '217 91% 60%',
      green: '142 76% 36%',
      pink: '330 81% 60%',
      orange: '25 95% 53%',
    };

    const root = document.documentElement;
    const hslValue = colorMap[preferences.colorScheme] || colorMap.purple;
    root.style.setProperty('--primary', hslValue);
  }, [preferences.colorScheme]);

  const updateOrgMutation = useMutation({
    mutationFn: async (data: typeof orgFormData) => {
      const res = await fetch("/api/organizations/current", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to update organization");
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations/current"] });
      toast({ title: "Organização atualizada com sucesso!" });
    },
    onError: (error: Error) => {
      toast({ title: "Erro ao atualizar organização", description: error.message, variant: "destructive" });
    },
  });

  const updatePreferencesMutation = useMutation({
    mutationFn: async (data: Partial<UserPreferences>) => {
      const res = await fetch("/api/user/preferences", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to update preferences");
      return res.json();
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/preferences"] });
      
      if (variables.language && variables.language !== i18n.language) {
        i18n.changeLanguage(variables.language);
        localStorage.setItem("i18nextLng", variables.language);
        toast({ 
          title: "Preferências atualizadas!", 
          description: "Idioma alterado com sucesso"
        });
        setTimeout(() => {
          window.location.reload();
        }, 1500);
      } else {
        toast({ title: "Preferências atualizadas com sucesso!" });
      }
    },
    onError: (error: Error) => {
      toast({ title: "Erro ao atualizar preferências", description: error.message, variant: "destructive" });
    },
  });

  const changePasswordMutation = useMutation({
    mutationFn: async (data: typeof passwordFormData) => {
      const res = await fetch("/api/user/change-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to change password");
      }
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Senha alterada com sucesso!" });
      setIsPasswordDialogOpen(false);
      setPasswordFormData({ currentPassword: "", newPassword: "", confirmPassword: "" });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
    },
    onError: (error: Error) => {
      toast({ title: "Erro ao alterar senha", description: error.message, variant: "destructive" });
    },
  });

  const setup2FAMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/user/2fa/setup", {
        method: "POST",
        headers: { "X-CSRF-Token": csrfToken },
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to setup 2FA");
      return res.json();
    },
    onSuccess: (data) => {
      setQrCodeUrl(data.qrCode);
      setIs2FADialogOpen(true);
    },
    onError: (error: Error) => {
      toast({ title: "Erro ao configurar 2FA", description: error.message, variant: "destructive" });
    },
  });

  const enable2FAMutation = useMutation({
    mutationFn: async (token: string) => {
      const res = await fetch("/api/user/2fa/enable", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        credentials: "include",
        body: JSON.stringify({ token }),
      });
      if (!res.ok) throw new Error("Código inválido");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Autenticação de dois fatores ativada!" });
      setIs2FADialogOpen(false);
      setTwoFactorToken("");
      refetch2FAStatus();
    },
    onError: (error: Error) => {
      toast({ title: "Erro ao ativar 2FA", description: error.message, variant: "destructive" });
    },
  });

  const disable2FAMutation = useMutation({
    mutationFn: async (token: string) => {
      const res = await fetch("/api/user/2fa/disable", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        credentials: "include",
        body: JSON.stringify({ token }),
      });
      if (!res.ok) throw new Error("Código inválido");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Autenticação de dois fatores desativada!" });
      setDisable2FAToken("");
      refetch2FAStatus();
    },
    onError: (error: Error) => {
      toast({ title: "Erro ao desativar 2FA", description: error.message, variant: "destructive" });
    },
  });

  const revokeSessionMutation = useMutation({
    mutationFn: async (sessionId: string) => {
      const res = await fetch(`/api/user/sessions/${sessionId}`, {
        method: "DELETE",
        headers: { "X-CSRF-Token": csrfToken },
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to revoke session");
      return res.json();
    },
    onSuccess: () => {
      toast({ title: "Sessão revogada com sucesso!" });
      refetchSessions();
    },
    onError: (error: Error) => {
      toast({ title: "Erro ao revogar sessão", description: error.message, variant: "destructive" });
    },
  });

  const handleChangePassword = () => {
    if (passwordFormData.newPassword !== passwordFormData.confirmPassword) {
      toast({ title: "As senhas não coincidem", variant: "destructive" });
      return;
    }
    if (passwordFormData.newPassword.length < 8) {
      toast({ title: "A senha deve ter pelo menos 8 caracteres", variant: "destructive" });
      return;
    }
    changePasswordMutation.mutate(passwordFormData);
  };

  const handleSaveOrganization = () => {
    updateOrgMutation.mutate(orgFormData);
  };

  const handleSavePreferences = () => {
    updatePreferencesMutation.mutate(preferences);
  };

  const handleCopyBackupCodes = () => {
    navigator.clipboard.writeText("Backup codes placeholder");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getDeviceIcon = (device: string) => {
    const lower = device.toLowerCase();
    if (lower.includes("mobile") || lower.includes("phone")) return <Smartphone className="h-5 w-5" />;
    if (lower.includes("tablet")) return <Tablet className="h-5 w-5" />;
    if (lower.includes("desktop") || lower.includes("laptop")) return <Laptop className="h-5 w-5" />;
    return <Monitor className="h-5 w-5" />;
  };

  if (isLoadingUser || isLoadingOrg) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-96">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="ml-2 text-muted-foreground">Carregando...</p>
        </div>
      </AppLayout>
    );
  }

  const sections = [
    { id: "personal" as Section, label: "Dados Pessoais", icon: UserIcon },
    { id: "organization" as Section, label: "Organização", icon: Building },
    { id: "preferences" as Section, label: "Preferências", icon: Palette },
    { id: "notifications" as Section, label: "Notificações", icon: Bell },
    { id: "security" as Section, label: "Segurança & Acesso", icon: Lock },
    { id: "subscription" as Section, label: "Assinatura", icon: CreditCard },
  ];

  return (
    <AppLayout>
      <motion.div 
        className="space-y-6"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div variants={itemVariants} className="flex flex-col gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Meu Perfil
            </h1>
            <p className="text-muted-foreground mt-1">
              Gerencie suas informações pessoais, preferências e configurações
            </p>
          </div>
        </motion.div>

        <motion.div variants={itemVariants}>
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="flex flex-col sm:flex-row items-center gap-6">
                <div className="relative group">
                  <Avatar className="h-24 w-24 border-4 border-primary/20">
                    <AvatarFallback className="text-2xl bg-gradient-to-br from-primary/20 to-primary/10">
                      {currentUser?.email?.charAt(0).toUpperCase() || "U"}
                    </AvatarFallback>
                  </Avatar>
                </div>
                <div className="flex-1 text-center sm:text-left">
                  <h2 className="text-2xl font-bold">{currentUser?.email}</h2>
                  <p className="text-muted-foreground">{organization?.name || "Organização"}</p>
                  <div className="flex gap-2 mt-2 justify-center sm:justify-start">
                    <Badge variant="secondary">{organization?.planType || "Free"}</Badge>
                    <Badge variant="outline" className="border-green-500/50 text-green-600">Ativo</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <motion.div variants={itemVariants} className="lg:col-span-1">
            <Card>
              <CardContent className="p-2">
                <nav className="flex flex-row lg:flex-col gap-1 overflow-x-auto lg:overflow-x-visible">
                  {sections.map((section) => (
                    <Button
                      key={section.id}
                      variant={activeSection === section.id ? "default" : "ghost"}
                      className={`justify-start whitespace-nowrap ${activeSection === section.id ? "" : "text-muted-foreground"}`}
                      onClick={() => setActiveSection(section.id)}
                    >
                      <section.icon className="h-4 w-4 mr-2 flex-shrink-0" />
                      <span className="hidden sm:inline">{section.label}</span>
                    </Button>
                  ))}
                </nav>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div variants={itemVariants} className="lg:col-span-3">
            {activeSection === "personal" && (
              <Card>
                <CardHeader>
                  <CardTitle>Dados Pessoais</CardTitle>
                  <CardDescription>Suas informações pessoais de acesso</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">E-mail</Label>
                    <Input id="email" value={currentUser?.email || ""} disabled />
                    <p className="text-sm text-muted-foreground">
                      Entre em contato com o suporte para alterar seu e-mail
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>Última alteração de senha</Label>
                    <p className="text-sm text-muted-foreground">
                      {currentUser?.passwordChangedAt 
                        ? new Date(currentUser.passwordChangedAt).toLocaleDateString('pt-BR')
                        : "Nunca alterada"}
                    </p>
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === "organization" && (
              <Card>
                <CardHeader>
                  <CardTitle>Informações da Organização</CardTitle>
                  <CardDescription>Dados da sua empresa ou organização</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="org-name">Nome da Organização</Label>
                      <Input
                        id="org-name"
                        value={orgFormData.name}
                        onChange={(e) => setOrgFormData({ ...orgFormData, name: e.target.value })}
                        placeholder="Minha Empresa Ltda"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="org-document">CNPJ</Label>
                      <Input
                        id="org-document"
                        value={orgFormData.document}
                        onChange={(e) => setOrgFormData({ ...orgFormData, document: e.target.value })}
                        placeholder="00.000.000/0000-00"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="org-email">E-mail</Label>
                      <Input
                        id="org-email"
                        type="email"
                        value={orgFormData.email}
                        onChange={(e) => setOrgFormData({ ...orgFormData, email: e.target.value })}
                        placeholder="contato@empresa.com"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="org-phone">Telefone</Label>
                      <Input
                        id="org-phone"
                        value={orgFormData.phone}
                        onChange={(e) => handlePhoneChange(e.target.value)}
                        placeholder="(00) 00000-0000"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="org-zipcode">CEP</Label>
                    <Input
                      id="org-zipcode"
                      value={orgFormData.zipCode}
                      onChange={(e) => handleZipCodeChange(e.target.value)}
                      placeholder="00000-000"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="org-address">Endereço</Label>
                    <Input
                      id="org-address"
                      value={orgFormData.address}
                      onChange={(e) => setOrgFormData({ ...orgFormData, address: e.target.value })}
                      placeholder="Rua, Avenida, etc"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="org-city">Cidade</Label>
                      <Input
                        id="org-city"
                        value={orgFormData.city}
                        onChange={(e) => setOrgFormData({ ...orgFormData, city: e.target.value })}
                        placeholder="São Paulo"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="org-state">Estado</Label>
                      <Input
                        id="org-state"
                        value={orgFormData.state}
                        onChange={(e) => setOrgFormData({ ...orgFormData, state: e.target.value })}
                        placeholder="SP"
                        maxLength={2}
                      />
                    </div>
                  </div>

                  <Button onClick={handleSaveOrganization} disabled={updateOrgMutation.isPending}>
                    {updateOrgMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Salvando...
                      </>
                    ) : (
                      "Salvar Alterações"
                    )}
                  </Button>
                </CardContent>
              </Card>
            )}

            {activeSection === "preferences" && (
              <Card>
                <CardHeader>
                  <CardTitle>Preferências</CardTitle>
                  <CardDescription>Personalize sua experiência na plataforma</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="theme">Tema</Label>
                    <Select 
                      value={preferences.themePreference} 
                      onValueChange={(value) => {
                        setPreferences({ ...preferences, themePreference: value });
                        setTheme(value);
                      }}
                    >
                      <SelectTrigger id="theme">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="light">
                          <div className="flex items-center gap-2">
                            <Sun className="h-4 w-4" />
                            Claro
                          </div>
                        </SelectItem>
                        <SelectItem value="dark">
                          <div className="flex items-center gap-2">
                            <Moon className="h-4 w-4" />
                            Escuro
                          </div>
                        </SelectItem>
                        <SelectItem value="system">
                          <div className="flex items-center gap-2">
                            <Monitor className="h-4 w-4" />
                            Sistema
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="language">Idioma</Label>
                    <Select 
                      value={preferences.language} 
                      onValueChange={(value) => setPreferences({ ...preferences, language: value })}
                    >
                      <SelectTrigger id="language">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pt-BR">Português (Brasil)</SelectItem>
                        <SelectItem value="en-US">English (US)</SelectItem>
                        <SelectItem value="es-ES">Español</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="color-scheme">Esquema de Cores</Label>
                    <div className="grid grid-cols-5 gap-2">
                      {["purple", "blue", "green", "pink", "orange"].map((color) => (
                        <button
                          key={color}
                          onClick={() => setPreferences({ ...preferences, colorScheme: color })}
                          className={`h-12 rounded-md border-2 transition-all ${
                            preferences.colorScheme === color ? "border-primary scale-110" : "border-transparent hover:border-muted"
                          }`}
                          style={{
                            background: color === "purple" ? "hsl(270 91% 65%)" :
                                      color === "blue" ? "hsl(217 91% 60%)" :
                                      color === "green" ? "hsl(142 76% 36%)" :
                                      color === "pink" ? "hsl(330 81% 60%)" :
                                      "hsl(25 95% 53%)"
                          }}
                        />
                      ))}
                    </div>
                  </div>

                  <Separator />

                  <Button onClick={handleSavePreferences} disabled={updatePreferencesMutation.isPending}>
                    {updatePreferencesMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Salvando...
                      </>
                    ) : (
                      "Salvar Preferências"
                    )}
                  </Button>
                </CardContent>
              </Card>
            )}

            {activeSection === "notifications" && (
              <Card>
                <CardHeader>
                  <CardTitle>Notificações</CardTitle>
                  <CardDescription>Controle como e quando você recebe notificações</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="email-notif">Notificações por E-mail</Label>
                      <p className="text-sm text-muted-foreground">
                        Receba atualizações importantes por e-mail
                      </p>
                    </div>
                    <Switch
                      id="email-notif"
                      checked={preferences.emailNotifications}
                      onCheckedChange={(checked) => 
                        setPreferences({ ...preferences, emailNotifications: checked })
                      }
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="activity-alerts">Alertas de Atividade</Label>
                      <p className="text-sm text-muted-foreground">
                        Notificações sobre atividades importantes
                      </p>
                    </div>
                    <Switch
                      id="activity-alerts"
                      checked={preferences.activityAlerts}
                      onCheckedChange={(checked) => 
                        setPreferences({ ...preferences, activityAlerts: checked })
                      }
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="weekly-reports">Relatórios Semanais</Label>
                      <p className="text-sm text-muted-foreground">
                        Receba um resumo semanal das suas finanças
                      </p>
                    </div>
                    <Switch
                      id="weekly-reports"
                      checked={preferences.weeklyReports}
                      onCheckedChange={(checked) => 
                        setPreferences({ ...preferences, weeklyReports: checked })
                      }
                    />
                  </div>

                  <Separator />

                  <Button onClick={handleSavePreferences} disabled={updatePreferencesMutation.isPending}>
                    {updatePreferencesMutation.isPending ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Salvando...
                      </>
                    ) : (
                      "Salvar Notificações"
                    )}
                  </Button>
                </CardContent>
              </Card>
            )}

            {activeSection === "security" && (
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Senha</CardTitle>
                    <CardDescription>Altere sua senha regularmente para manter sua conta segura</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={() => setIsPasswordDialogOpen(true)}>
                      <Lock className="h-4 w-4 mr-2" />
                      Alterar Senha
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Autenticação de Dois Fatores (2FA)</CardTitle>
                    <CardDescription>
                      Adicione uma camada extra de segurança à sua conta
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Status 2FA</Label>
                        <p className="text-sm text-muted-foreground">
                          {twoFactorStatus?.enabled ? "Ativado" : "Desativado"}
                        </p>
                      </div>
                      <Badge variant={twoFactorStatus?.enabled ? "default" : "secondary"}>
                        {twoFactorStatus?.enabled ? "Ativo" : "Inativo"}
                      </Badge>
                    </div>

                    <Separator />

                    {!twoFactorStatus?.enabled ? (
                      <Button onClick={() => setup2FAMutation.mutate()} disabled={setup2FAMutation.isPending}>
                        {setup2FAMutation.isPending ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Configurando...
                          </>
                        ) : (
                          <>
                            <Shield className="h-4 w-4 mr-2" />
                            Ativar 2FA
                          </>
                        )}
                      </Button>
                    ) : (
                      <div className="space-y-4">
                        <Alert>
                          <Shield className="h-4 w-4" />
                          <AlertDescription>
                            Autenticação de dois fatores está ativa e protegendo sua conta
                          </AlertDescription>
                        </Alert>
                        <div className="space-y-2">
                          <Label htmlFor="disable-2fa-token">Digite o código para desativar</Label>
                          <div className="flex gap-2">
                            <InputOTP
                              maxLength={6}
                              value={disable2FAToken}
                              onChange={setDisable2FAToken}
                            >
                              <InputOTPGroup>
                                <InputOTPSlot index={0} />
                                <InputOTPSlot index={1} />
                                <InputOTPSlot index={2} />
                                <InputOTPSlot index={3} />
                                <InputOTPSlot index={4} />
                                <InputOTPSlot index={5} />
                              </InputOTPGroup>
                            </InputOTP>
                            <Button 
                              variant="destructive" 
                              onClick={() => disable2FAMutation.mutate(disable2FAToken)}
                              disabled={disable2FAMutation.isPending || disable2FAToken.length !== 6}
                            >
                              {disable2FAMutation.isPending ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                "Desativar"
                              )}
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Sessões Ativas</CardTitle>
                    <CardDescription>
                      Gerencie os dispositivos conectados à sua conta
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={() => setIsSessionsDialogOpen(true)}>
                      <Monitor className="h-4 w-4 mr-2" />
                      Ver Sessões ({activeSessions?.length || 0})
                    </Button>
                  </CardContent>
                </Card>
              </div>
            )}

            {activeSection === "subscription" && (
              <Card>
                <CardHeader>
                  <CardTitle>Assinatura</CardTitle>
                  <CardDescription>Gerencie seu plano e assinatura</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Plano Atual</Label>
                      <p className="text-2xl font-bold">
                        {subscription?.planType || organization?.planType || "Free"}
                      </p>
                    </div>
                    <Badge variant={subscription?.status === "active" ? "default" : "secondary"}>
                      {subscription?.status || "free"}
                    </Badge>
                  </div>

                  {subscription && (
                    <>
                      <Separator />

                      <div className="space-y-2">
                        <Label>Próximo Pagamento</Label>
                        <p className="text-sm text-muted-foreground">
                          {subscription.currentPeriodEnd 
                            ? new Date(subscription.currentPeriodEnd).toLocaleDateString('pt-BR')
                            : "N/A"}
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label>Valor</Label>
                        <p className="text-sm text-muted-foreground">
                          {subscription.amount ? `R$ ${parseFloat(subscription.amount).toFixed(2)}` : "N/A"}
                        </p>
                      </div>

                      <Separator />
                    </>
                  )}

                  <Button variant="outline" onClick={() => window.location.href = "/app/pricing"}>
                    <CreditCard className="h-4 w-4 mr-2" />
                    {subscription ? "Gerenciar Assinatura" : "Escolher Plano"}
                  </Button>
                </CardContent>
              </Card>
            )}
          </motion.div>
        </div>
      </motion.div>

      <Dialog open={isPasswordDialogOpen} onOpenChange={setIsPasswordDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Alterar Senha</DialogTitle>
            <DialogDescription>
              Digite sua senha atual e escolha uma nova senha segura
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="current-password">Senha Atual</Label>
              <PasswordInput
                id="current-password"
                value={passwordFormData.currentPassword}
                onChange={(e) => setPasswordFormData({ ...passwordFormData, currentPassword: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="new-password">Nova Senha</Label>
              <PasswordInput
                id="new-password"
                value={passwordFormData.newPassword}
                onChange={(e) => setPasswordFormData({ ...passwordFormData, newPassword: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="confirm-password">Confirmar Nova Senha</Label>
              <PasswordInput
                id="confirm-password"
                value={passwordFormData.confirmPassword}
                onChange={(e) => setPasswordFormData({ ...passwordFormData, confirmPassword: e.target.value })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPasswordDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleChangePassword} disabled={changePasswordMutation.isPending}>
              {changePasswordMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Alterando...
                </>
              ) : (
                "Alterar Senha"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={is2FADialogOpen} onOpenChange={setIs2FADialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Configurar Autenticação de Dois Fatores</DialogTitle>
            <DialogDescription>
              Escaneie o QR Code com seu aplicativo autenticador (Google Authenticator, Authy, etc.)
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {qrCodeUrl && (
              <div className="flex justify-center p-4 bg-white rounded-lg">
                <img src={qrCodeUrl} alt="QR Code 2FA" className="w-64 h-64" />
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="2fa-token">Digite o código de 6 dígitos</Label>
              <InputOTP
                maxLength={6}
                value={twoFactorToken}
                onChange={setTwoFactorToken}
              >
                <InputOTPGroup className="w-full justify-center">
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                  <InputOTPSlot index={4} />
                  <InputOTPSlot index={5} />
                </InputOTPGroup>
              </InputOTP>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIs2FADialogOpen(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={() => enable2FAMutation.mutate(twoFactorToken)}
              disabled={enable2FAMutation.isPending || twoFactorToken.length !== 6}
            >
              {enable2FAMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Ativando...
                </>
              ) : (
                "Ativar 2FA"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isSessionsDialogOpen} onOpenChange={setIsSessionsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Sessões Ativas</DialogTitle>
            <DialogDescription>
              Dispositivos e navegadores conectados à sua conta
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {activeSessions?.map((session) => (
              <Card key={session.sid} className={session.current ? "border-primary" : ""}>
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className="mt-1">
                        {getDeviceIcon(session.device)}
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{session.device}</p>
                          {session.current && (
                            <Badge variant="default" className="text-xs">Sessão Atual</Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {session.browser} • {session.os}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          IP: {session.ipAddress}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Última atividade: {new Date(session.lastActivity).toLocaleString('pt-BR')}
                        </p>
                      </div>
                    </div>
                    {!session.current && (
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => revokeSessionMutation.mutate(session.sid)}
                        disabled={revokeSessionMutation.isPending}
                      >
                        {revokeSessionMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <>
                            <X className="h-4 w-4 mr-1" />
                            Revogar
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
