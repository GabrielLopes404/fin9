import { ReactNode } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { canAccessRoute, getLandingRoute } from "@/lib/rbac";
import { Loader2 } from "lucide-react";

interface ProtectedRouteProps {
  children: ReactNode;
  requireAdmin?: boolean;
}

export function ProtectedRoute({ children, requireAdmin = false }: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    setLocation("/login");
    return null;
  }

  const currentPath = window.location.pathname;
  
  if (!canAccessRoute(user, currentPath)) {
    const defaultRoute = getLandingRoute(user);
    setLocation(defaultRoute);
    return null;
  }

  if (requireAdmin && user.role !== "OWNER" && user.role !== "ADMIN") {
    const defaultRoute = getLandingRoute(user);
    setLocation(defaultRoute);
    return null;
  }

  return <>{children}</>;
}
