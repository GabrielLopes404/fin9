import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, Check, Zap, TrendingUp, Shield } from "lucide-react";
import { motion, useScroll, useTransform } from "framer-motion";
import { useLocation } from "wouter";
import { useRef } from "react";

export default function CTASection() {
  const [, setLocation] = useLocation();
  const containerRef = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["100px", "-100px"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5, 1], [0.5, 1, 0.5]);
  
  return (
    <section ref={containerRef} className="relative py-32 px-4 sm:px-6 lg:px-8 overflow-hidden">
      {/* Enhanced vibrant gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-violet-600 via-fuchsia-600 via-purple-600 to-cyan-600" />
      
      {/* Animated gradient mesh overlay */}
      <motion.div 
        className="absolute inset-0"
        animate={{
          backgroundPosition: ['0% 0%', '100% 100%', '0% 0%'],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear"
        }}
        style={{
          backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(255,255,255,0.15) 0%, transparent 50%), radial-gradient(circle at 80% 80%, rgba(255,255,255,0.15) 0%, transparent 50%)',
          backgroundSize: '200% 200%'
        }}
      />

      {/* Floating animated orbs */}
      <motion.div
        style={{ y, opacity }}
        className="absolute top-10 left-10 w-96 h-96 bg-white/10 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 180, 360],
        }}
        transition={{
          duration: 15,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      <motion.div
        style={{ y: useTransform(scrollYProgress, [0, 1], ["-80px", "120px"]), opacity }}
        className="absolute bottom-10 right-10 w-96 h-96 bg-white/10 rounded-full blur-3xl"
        animate={{
          scale: [1.2, 1, 1.2],
          rotate: [360, 180, 0],
        }}
        transition={{
          duration: 18,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      {/* Animated grid pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:64px_64px] opacity-30" />
      
      <div className="max-w-5xl mx-auto text-center relative z-10">
        {/* Enhanced badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8, y: -20 }}
          whileInView={{ opacity: 1, scale: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, type: "spring" }}
          className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-white/15 backdrop-blur-xl border-2 border-white/30 text-base font-bold text-white mb-10 shadow-2xl shadow-black/20 relative overflow-hidden group"
        >
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
            animate={{ x: ['-200%', '200%'] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: "linear", repeatDelay: 1 }}
          />
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          >
            <Sparkles className="h-6 w-6" />
          </motion.div>
          <span className="relative z-10">🎉 Oferta Especial: 7 dias grátis + Bônus exclusivo</span>
        </motion.div>

        {/* Main headline with enhanced animation */}
        <motion.h2 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, ease: [0.25, 0.4, 0.25, 1] }}
          className="text-4xl sm:text-6xl lg:text-7xl font-bold mb-8 text-white leading-tight"
          data-testid="text-cta-title"
        >
          <span className="inline-block">
            Pronto para{" "}
            <span className="relative inline-block">
              <motion.span
                className="absolute -inset-2 bg-white/20 blur-2xl rounded-2xl"
                animate={{ 
                  scale: [1, 1.2, 1],
                  opacity: [0.3, 0.5, 0.3]
                }}
                transition={{ duration: 3, repeat: Infinity }}
              />
              <span className="relative bg-white bg-clip-text text-transparent drop-shadow-2xl">
                transformar
              </span>
            </span>
          </span>
          <br />
          <span className="inline-block">sua gestão financeira?</span>
        </motion.h2>
        
        {/* Subtitle */}
        <motion.p 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-xl sm:text-2xl mb-12 text-white/95 max-w-3xl mx-auto leading-relaxed font-medium"
          data-testid="text-cta-subtitle"
        >
          Junte-se a{" "}
          <span className="font-bold text-white drop-shadow-lg">12.500+ empresas</span>
          {" "}que já estão crescendo com o LUCREI. 
          <span className="block mt-2 text-lg text-white/90">
            Teste grátis por 7 dias, sem cartão de crédito, sem compromisso.
          </span>
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-5 justify-center mb-12"
        >
          <motion.div 
            whileHover={{ scale: 1.05, y: -3 }} 
            whileTap={{ scale: 0.98 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
          >
            <Button 
              size="lg" 
              variant="secondary"
              className="text-lg px-12 py-8 shadow-2xl hover:shadow-3xl transition-all relative overflow-hidden group bg-white text-violet-600 hover:bg-white/95 font-bold"
              data-testid="button-cta-primary"
              onClick={() => setLocation('/register')}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-transparent via-violet-500/10 to-transparent"
                animate={{ x: ['-200%', '200%'] }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear", repeatDelay: 1 }}
              />
              <span className="relative z-10 flex items-center gap-3">
                Começar agora — 7 dias grátis
                <motion.div
                  animate={{ x: [0, 5, 0] }}
                  transition={{ duration: 1.5, repeat: Infinity }}
                >
                  <ArrowRight className="h-6 w-6" />
                </motion.div>
              </span>
            </Button>
          </motion.div>
          
          <motion.div 
            whileHover={{ scale: 1.05, y: -3 }} 
            whileTap={{ scale: 0.98 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
          >
            <Button 
              size="lg" 
              variant="outline"
              className="text-lg px-12 py-8 bg-white/15 backdrop-blur-xl border-2 border-white/40 text-white hover:bg-white/25 transition-all shadow-xl font-bold"
              data-testid="button-cta-secondary"
            >
              Falar com especialista
            </Button>
          </motion.div>
        </motion.div>

        {/* Enhanced trust indicators */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex flex-wrap items-center justify-center gap-8 text-white mb-12"
        >
          {[
            { icon: Check, text: 'Sem cartão de crédito' },
            { icon: Shield, text: 'Dados 100% seguros' },
            { icon: Zap, text: 'Setup em 2 minutos' },
            { icon: TrendingUp, text: 'Cancele quando quiser' }
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5 + i * 0.1, type: "spring" }}
              whileHover={{ scale: 1.1, y: -3 }}
              className="flex items-center gap-3 px-6 py-3 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 shadow-xl"
            >
              <div className="h-6 w-6 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <item.icon className="h-4 w-4 text-white" strokeWidth={2.5} />
              </div>
              <span className="text-sm font-semibold">{item.text}</span>
            </motion.div>
          ))}
        </motion.div>

        {/* Social proof section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="pt-12 border-t border-white/20"
        >
          <p className="text-white/90 text-base mb-6 font-medium">
            🌟 Empresas que já cresceram com LUCREI:
          </p>
          <div className="flex flex-wrap items-center justify-center gap-6">
            {['TechStart Solutions', 'Construtora Moderna', 'Studio Criativo', 'Digital Agency', 'E-commerce Plus'].map((company, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.7 + i * 0.05, type: "spring" }}
                whileHover={{ scale: 1.1 }}
                className="px-5 py-2.5 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 text-sm font-semibold text-white/95 shadow-lg"
              >
                {company}
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
